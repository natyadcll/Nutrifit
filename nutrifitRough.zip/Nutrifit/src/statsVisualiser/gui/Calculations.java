package statsVisualiser.gui;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class Calculations {
	public double BMR(final String name, final String sex, int height, int weight, final String date,
			final String units) {
		if(units.equals("I")) {
			weight = (int) ImpToMetWeight(weight);
			height = (int) ImpToMetHeight(height);
		}
		double BMR = 0.0;
		if(sex.equals("M")) {
    		BMR = 88.362 + (13.397*weight) + (4.799*height) - (5.677*(calculateAge(date)));
    	}
    	if(sex.equals("F")) {
    		BMR = 447.593 + (9.247*weight) + (3.098*height) - (4.330*(calculateAge(date)));
    	}
		return BMR;
	}
	public double ImpToMetWeight(int weight) {
		return weight/2.205;
	}
	public double ImpToMetHeight(int height) {
		int feet = height / 100; 
        int inches = height % 100; 

        double heightInCm = feet * 30.48 + inches * 2.54;
        return heightInCm;
	}
	public double caloriesBurnt(double bmr, double met, double durationInMinutes) {
		double durationInHours = durationInMinutes / 60.0;
        return bmr * (met * durationInHours / 24.0);
	}
	public int calculateAge(String date) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate birthDate = LocalDate.parse(date, formatter);

        LocalDate currentDate = LocalDate.now();
        return Period.between(birthDate, currentDate).getYears();
	}
	public double met(Excercise exercise) {
		String intensity = exercise.getInten();
		double met = 0.0;
		if(intensity.equals("Low"))
			met = 1.0;
		else if(intensity.equals("Medium"))
			met = 2.0;
		else if (intensity.equals("High"))
			met = 3.0;
		else if (intensity.equals("Very High"))
			met = 6.0;
		return met;
	}

}
