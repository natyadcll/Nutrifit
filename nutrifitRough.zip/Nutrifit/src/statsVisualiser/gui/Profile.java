package statsVisualiser.gui;

import javax.swing.*;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.text.ParseException;

import java.sql.*;

public class Profile extends JFrame {

	private JPanel panel1;
	private String from;

	public Profile() {
		setTitle("Main Page");
		setSize(500, 400);
		viewMainForm();
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		from = "main";
	}

	public void viewMainForm() {
		panel1 = new JPanel();
		JButton login = new JButton("Choose Profile");
		panel1.add(login);
		JButton signup = new JButton("Create Account");
		panel1.add(signup);
		add(panel1);
		login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Subsplash();
			}
		});

		signup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AccountManager();
			}
		});
	}

	public boolean checkNameExists(final String name) {
		Connection con1 = connection.connectDB();
		try {

			String sql = "SELECT COUNT(*) FROM profile WHERE name = ?";
			PreparedStatement ps = con1.prepareStatement(sql);
			ps.setString(1, name);
			ResultSet resultSet = ps.executeQuery();
			if (resultSet.next()) {
				int count = resultSet.getInt(1);
				return count > 0; 
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}

	public boolean weightHeightValid(String entry) {
		try {
			double entry1 = Double.parseDouble(entry);

		} catch (NumberFormatException ex) {
			return false;
		}
		return true;
	}

	public boolean dateCorrect(String date) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		dateFormat.setLenient(false);
		try {
			dateFormat.parse(date);
			return true;
		} catch (ParseException | ClassCastException e) { 
			return false;
		}
	}

	public String getSex(final String name) {
		String sex = null;
		Connection con1 = connection.connectDB();
		try {

			String sql = "SELECT * FROM profile WHERE name = ?";
			PreparedStatement ps = con1.prepareStatement(sql);
			ps.setString(1, name);
			ResultSet resultSet = ps.executeQuery();
			if (resultSet.next()) {
				sex = resultSet.getString("sex");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sex;
	}

	public int getHeight(final String name) {
		int height = 0;
		Connection con1 = connection.connectDB();
		try {

			String sql = "SELECT * FROM profile WHERE name = ?";
			PreparedStatement ps = con1.prepareStatement(sql);
			ps.setString(1, name);
			ResultSet resultSet = ps.executeQuery();
			if (resultSet.next()) {
				height = resultSet.getInt("height");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return height;
	}

	public int getWeight(final String name) {
		int weight = 0;
		Connection con1 = connection.connectDB();
		try {

			String sql = "SELECT * FROM profile WHERE name = ?";
			PreparedStatement ps = con1.prepareStatement(sql);
			ps.setString(1, name);
			ResultSet resultSet = ps.executeQuery();
			if (resultSet.next()) {
				weight = resultSet.getInt("weight");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return weight;
	}

	public String getDate(final String name) {
		String date = null;
		Connection con1 = connection.connectDB();
		try {

			String sql = "SELECT * FROM profile WHERE name = ?";
			PreparedStatement ps = con1.prepareStatement(sql);
			ps.setString(1, name);
			ResultSet resultSet = ps.executeQuery();
			if (resultSet.next()) {
				date = resultSet.getString("date");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}

	public String getunit(final String name) {
		String sex = null;
		Connection con1 = connection.connectDB();
		try {

			String sql = "SELECT * FROM profile WHERE name = ?";
			PreparedStatement ps = con1.prepareStatement(sql);
			ps.setString(1, name);
			ResultSet resultSet = ps.executeQuery();
			if (resultSet.next()) {
				sex = resultSet.getString("units");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sex;
	}

	public void AccountManager() {
		from = "account";
		panel1 = new JPanel(new GridLayout(7, 1));

		JLabel NameLabel = new JLabel("Name:");
		panel1.add(NameLabel);
		final JTextField NameField = new JTextField();
		panel1.add(NameField);

		JLabel sLabel = new JLabel("Sex:");
		panel1.add(sLabel);
		
		String[] sexOptions = { "M", "F" };
		final JComboBox<String> sFeild = new JComboBox<>(sexOptions);
		panel1.add(sFeild);

		JLabel HeightLabel = new JLabel("Height:");
		panel1.add(HeightLabel);
		final JTextField HeightField = new JTextField();
		panel1.add(HeightField);

		JLabel WeightLabel = new JLabel("Weight:");
		panel1.add(WeightLabel);
		final JTextField WeightField = new JTextField();
		panel1.add(WeightField);

		JLabel BirthLabel = new JLabel("Date of birth YYYY-MM-DD:");
		panel1.add(BirthLabel);
		final JTextField BirthField = new JTextField();
		panel1.add(BirthField);

		JLabel uLabel = new JLabel("Imperial(I) or Metric(M):");
		panel1.add(uLabel);
		String[] uOptions = { "I", "M" };

		final JComboBox<String> uFeild = new JComboBox<>(uOptions);
		panel1.add(uFeild);

		JButton enterButton = new JButton("Enter");
		panel1.add(enterButton);

		JButton cancelButton = new JButton("Cancel");
		panel1.add(cancelButton);

		getContentPane().removeAll();
		add(panel1);
		setVisible(true);

		enterButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = NameField.getText();
				String sex = (String) sFeild.getSelectedItem();
				String height = HeightField.getText();
				String weight = WeightField.getText();
				String date = BirthField.getText();
				String units = (String) uFeild.getSelectedItem();
				if (name.isEmpty() || sex.isEmpty() || height.isEmpty() || weight.isEmpty() || date.isEmpty()
						|| units.isEmpty()) {
					JOptionPane.showMessageDialog(null, "Please fill in all fields.");
					AccountManager();
				} else {

					if (checkNameExists(name) == true) {
						JOptionPane.showMessageDialog(null, "Name already exists");
						AccountManager();
					}
					if (!weightHeightValid(weight) || !weightHeightValid(height)
							|| !dateCorrect(date)) {
						JOptionPane.showMessageDialog(null, "please enter a valid height, weight, and date");
						AccountManager();
					} else {
						AddData(name, sex, Integer.parseInt(height), Integer.parseInt(height), date, units);
					}

				}

			}
		});

		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (from.equalsIgnoreCase("main"))
					viewMainForm();
				else if (from.equalsIgnoreCase("subsplash"))
					Subsplash();
			}
		});

	}

	private void AddData(String name, String sex, int height, int weight, String date, String units) {
		Connection con = connection.connectDB();
		PreparedStatement ps = null;
		try {
			String sql = "INSERT INTO profile (`name`, `sex`, `height`, `weight`, `date`, `units`) VALUES (?, ?, ?, ?, ?, ?)";
			ps = con.prepareStatement(sql);
			ps.setString(1, name);
			ps.setString(2, sex);
			ps.setInt(3, height);
			ps.setInt(4, weight);
			ps.setString(5, date);
			ps.setString(6, units);

			int rowsAffected = ps.executeUpdate();
			if (rowsAffected > 0) {
				JOptionPane.showMessageDialog(null, "Profile saved", "Success", JOptionPane.INFORMATION_MESSAGE);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		ProfileView(name);

	}

	private void Subsplash() {
		from = "subsplash";
		panel1 = new JPanel();
		JComboBox<String> nameDropdown = new JComboBox<String>();
		getContentPane().removeAll();
		add(panel1);
		panel1.add(nameDropdown);

		JButton selectButton = new JButton("Select");
		panel1.add(selectButton);

		Connection con1 = connection.connectDB();
		try {

			String sql = "SELECT name FROM profile";

			PreparedStatement ps = con1.prepareStatement(sql);
			Statement statement = con1.createStatement();

			ResultSet resultSet = statement.executeQuery(sql);

			if (!resultSet.next()) {
				JOptionPane.showMessageDialog(null, "No profiles found. Please create a profile.");
				AccountManager();
			}
			else {
				resultSet = statement.executeQuery(sql);
				while (resultSet.next()) {
					nameDropdown.addItem(resultSet.getString("name"));
				}
			}
		} catch (SQLException e) {
			System.out.println(e);
		}


		panel1.setVisible(true);

		selectButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String selectedName = (String) nameDropdown.getSelectedItem();
				ProfileView(selectedName);
			}
		});

	}

	public void ProfileView(final String name) {
		final String sex = getSex(name);
		final int height = getHeight(name);
		final int weight = getWeight(name);
		final String date = getDate(name);
		final String units = getunit(name);
		String w = "lbs";
		String h = "in";
		if (units.equals("M")) {
			w = "kg";
			h = "cm";
		}

		panel1.removeAll();

		panel1.setLayout(new GridLayout(12, 1));

		JLabel NameLabel = new JLabel("Name: " + name);
		panel1.add(NameLabel);

		JLabel sLabel = new JLabel("Sex: " + sex);
		panel1.add(sLabel);

		JLabel HeightLabel = new JLabel("Height: " + height + " " + h);
		panel1.add(HeightLabel);

		JLabel WeightLabel = new JLabel("Weight: " + weight + " " + w);
		panel1.add(WeightLabel);

		JLabel BirthLabel = new JLabel("Date of birth: " + date);
		panel1.add(BirthLabel);

		JButton editButton = new JButton("Edit Profile");
		panel1.add(editButton);
		editButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EditProfile(name, sex, height, weight, date, units);
			}
		});

		JButton logDietButton = new JButton("Log Diet");
		panel1.add(logDietButton);
		JFrame frame = this;
		logDietButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				try {
					new Diet(name, frame);
				} catch (SQLException ex) {
					throw new RuntimeException(ex);
				}
			}
		});
		JButton exerciseLogButton = new JButton("Log Exercise");
		panel1.add(exerciseLogButton);
		exerciseLogButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new Excercise(name, sex, height, weight, date, units);
			}
		});
	
		JButton calExvisualization = new JButton("calory and exercise chart");
		panel1.add(calExvisualization);
		calExvisualization.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new calexvisualization();
			}
		});
			
			
		JButton Visualization = new JButton("nutrient Intake chart");
		panel1.add(Visualization);
		Visualization.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new visualization();
		}});
		JButton weightToLoseButton = new JButton("Weight to Lose");
		panel1.add(weightToLoseButton);
		weightToLoseButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				new WeightToLose(name, frame);
			}
		});
		JButton change = new JButton("See how your diet aligns to CFG");
        panel1.add(change);
        change.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new alignCFG(name);
                dispose();
            }
        });

		getContentPane().revalidate();
		getContentPane().repaint();

		panel1.revalidate();
		panel1.repaint();
		panel1.setVisible(true);
		
	}

	private void EditProfile(final String name, final String sex, final int height, final int weight, final String date,
							 final String units) {
		panel1.removeAll();
		panel1 = new JPanel(new GridLayout(7, 1));


		String w = "lbs";
		String h = "in";
		if (units.equals("M")) {
			w = "kg";
			h = "cm";
		}

		JLabel NameLabel = new JLabel("Name: " + name);
		panel1.add(NameLabel);
		final JTextField NameField = new JTextField();
		panel1.add(NameField);

		JLabel sLabel = new JLabel("Sex: " + sex);
		panel1.add(sLabel);
		String[] sexOptions = { "M", "F" };
		final JComboBox<String> sFeild = new JComboBox<>(sexOptions);
		panel1.add(sFeild);

		JLabel HeightLabel = new JLabel("Height: " + height + " " + h);
		panel1.add(HeightLabel);
		final JTextField HeightField = new JTextField();
		panel1.add(HeightField);

		JLabel WeightLabel = new JLabel("Weight: " + weight + " " + w);
		panel1.add(WeightLabel);
		final JTextField WeightField = new JTextField();
		panel1.add(WeightField);

		JLabel BirthLabel = new JLabel("Date of birth: " + date);
		panel1.add(BirthLabel);
		final JTextField BirthField = new JTextField();
		panel1.add(BirthField);

		JLabel uLabel = new JLabel("Imperial(I) or Metric(M):");
		panel1.add(uLabel);
		String[] uOptions = { "I", "M" };

		final JComboBox<String> uFeild = new JComboBox<>(uOptions);
		panel1.add(uFeild);

		JButton enterButton = new JButton("Enter");
		panel1.add(enterButton);

		getContentPane().removeAll();
		add(panel1);
		setVisible(true);

		enterButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name1 = NameField.getText();
				String sex1 = (String) sFeild.getSelectedItem();
				String height1 = HeightField.getText();
				String weight1 = WeightField.getText();
				String date1 = BirthField.getText();
				String units1 = (String) uFeild.getSelectedItem();
				if (name1.isEmpty()) {
					name1 = name;
				}
				if (height1.isEmpty() || !weightHeightValid(height1)) {
					height1 = Integer.toString(height);
				}
				if (weight1.isEmpty() || !weightHeightValid(weight1)) {
					weight1 = Integer.toString(weight);
				}
				if (date1.isEmpty() || !dateCorrect(date)) {
					date1 = date;
				}
				sendForReview(name, name1, sex1, height1, weight1, date1, units1);
			}

		});
	}

	private void sendForReview(String name, String name1, String sex, String height, String weight, String date,
							   String units) {
		Connection con = connection.connectDB();
		if (!name.equals(name1)) {
			PreparedStatement ps = null;
			try {
				String sql = "UPDATE `new_schema`.`profile` SET `name` = ? WHERE (`name` = ?)";
				ps = con.prepareStatement(sql);
				ps.setString(1, name1);
				ps.setString(2, name);

				int rowsAffected = ps.executeUpdate();
				if (rowsAffected > 0) {

				}
				

			} catch (SQLException e) {
				e.printStackTrace();
			}
			name = name1;
		}
		try {
			Connection con1 = connection.connectDB();
			PreparedStatement ps = null;
			String sql = "UPDATE `profile` SET `sex` = ?, `height` = ?, `weight` = ?, `date` = ?, `units` = ? WHERE (`name` = ?)";
			ps = con1.prepareStatement(sql);
			ps.setString(1, sex);
			ps.setInt(2, Integer.parseInt(height));
			ps.setInt(3, Integer.parseInt(weight));
			ps.setString(4, date);
			ps.setString(5, units);
			ps.setString(6, name);

			int rowsAffected = ps.executeUpdate();
			if (rowsAffected > 0) {
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		ProfileView(name);
	}
	public static void main(String[] args) {
		 new Profile();
	}

}