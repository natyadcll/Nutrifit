package statsVisualiser.gui;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class connection {

	private static Connection con = null;

	public static Connection connectDB()

	{

		try {

			Class.forName("com.mysql.cj.jdbc.Driver");

			Connection con = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/nutrifit",
				"root", "Natalyaleja2003#");

			return con;
		}

		catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);

			return null;
		}
	}
	
	public static void buildDatabase() throws SQLException {
		if (connectDB() == null) {
			System.out.println("Connection failed");
			System.exit(0);
		}

		try {
			Statement stmt = con.createStatement();
			stmt.executeQuery("SELECT * FROM profile");
		} catch (SQLException e) {
			System.out.println("Building database. Please wait...");
			buildProfileTable();
			buildFoodNameTable();
			buildNutrientNameTable();
			buildNutrientAmountTable();
			buildDietLogTable();
			System.out.println("Database built successfully.");
		}

	}
	
	private static void buildProfileTable() throws SQLException {
		con.prepareStatement("CREATE TABLE IF NOT EXISTS profile (\n" +
				"    id INT AUTO_INCREMENT PRIMARY KEY,\n" +
				"    name VARCHAR(255),\n" +
				"    sex CHAR(1),\n" +
				"    weight DECIMAL(8,2),\n" +
				"    height DECIMAL(8,2),\n" +
				"    date DATE,\n" +
				"    units VARCHAR(50)\n" +
				");").execute();
	}
	
	public static void buildDietLogTable() throws SQLException {
		con.prepareStatement("CREATE TABLE IF NOT EXISTS meal_log (\n" +
				"    id INT AUTO_INCREMENT PRIMARY KEY,\n" +
				"    profile_id INT,\n" +
				"    date DATE,\n" +
				"    type VARCHAR(10)\n" +
				");").execute();

		con.prepareStatement("CREATE TABLE IF NOT EXISTS meal_content (\n" +
				"    id INT AUTO_INCREMENT PRIMARY KEY,\n" +
				"    meal_id INT,\n" +
				"    food_id INT,\n" +
				"    amount DECIMAL(10, 2)\n" +
				");").execute();
	}

	private static List<List<String>> loadFile(String fileName, List<Integer> columns) {
		List<List<String>> result = new ArrayList<>();

		Pattern pattern = Pattern.compile(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
		String csvFile = "./res/" + fileName;
		String line;
		boolean isFirstLine = true;

		try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
			while ((line = br.readLine()) != null) {
				if (isFirstLine) {
					isFirstLine = false;
					continue;
				}
				else if (line.isEmpty())
					continue;

				String[] data = pattern.split(line);

				List<String> row = new ArrayList<>();
				for (int i = 0; i < columns.size(); i++) {
					row.add(data[columns.get(i)].replace("\"", ""));
				}
				result.add(row);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	public static void buildFoodNameTable() throws SQLException {
		connectDB();
		con.prepareStatement("CREATE TABLE IF NOT EXISTS food_name (\n" +
				"    id INT PRIMARY KEY,\n" +
				"    description VARCHAR(255)\n" +
				");").execute();

		List<List<String>> result = loadFile("FOOD NAME.csv", List.of(0, 4));

		for (List<String> row : result) {
			PreparedStatement ps = con.prepareStatement("INSERT INTO food_name (id, description) VALUES (?, ?)");
			ps.setInt(1, Integer.parseInt(row.get(0)));
			ps.setString(2, row.get(1));
			ps.executeUpdate();
		}
	}

	private static void buildNutrientNameTable() throws SQLException {
		con.prepareStatement("CREATE TABLE IF NOT EXISTS nutrient_name (\n" +
				"    id INT PRIMARY KEY,\n" +
				"    unit VARCHAR(5),\n" +
				"    name VARCHAR(255)\n" +
				");").execute();

		List<List<String>> result = loadFile("NUTRIENT NAME.csv", List.of(0, 3, 4));

		for (List<String> row : result) {
			PreparedStatement ps = con.prepareStatement("INSERT INTO nutrient_name (id, unit, name) VALUES (?, ?, ?)");
			ps.setInt(1, Integer.parseInt(row.get(0)));
			ps.setString(2, row.get(1));
			ps.setString(3, row.get(2));
			ps.executeUpdate();
		}
	}

	private static void buildNutrientAmountTable() throws SQLException {
		con.prepareStatement("CREATE TABLE nutrient_amount (\n" +
				"    id INT AUTO_INCREMENT PRIMARY KEY,\n" +
				"    food_id INT,\n" +
				"    nutrient_id INT,\n" +
				"    amount DECIMAL(10, 2)\n" +
				");\n").execute();

		List<List<String>> result = loadFile("NUTRIENT AMOUNT.csv", List.of(0, 1, 2));

		for (List<String> row : result) {
			PreparedStatement ps = con.prepareStatement("INSERT INTO nutrient_amount (food_id, nutrient_id, amount) VALUES (?, ?, ?)");
			ps.setInt(1, Integer.parseInt(row.get(0)));
			ps.setInt(2, Integer.parseInt(row.get(1)));
			ps.setDouble(3, Double.parseDouble(row.get(2)));
			ps.executeUpdate();
		}
	
}


}

