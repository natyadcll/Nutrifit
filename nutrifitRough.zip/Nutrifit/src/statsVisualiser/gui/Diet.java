package statsVisualiser.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Vector;

public class Diet extends JFrame {
    private final JFrame source;
    private final JFrame thisFrame = this;
    private JPanel panel;
    private final String name;

    public Diet(String name, JFrame source) throws SQLException {
        this.source = source;
        this.name = name;

        panel = new JPanel();
        add(panel);

        setTitle("Diet Logs");
        setSize(500, 550);

        viewMainForm();

        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

    }

    public void viewMainForm() throws SQLException {

        panel.removeAll();
        panel.setLayout(new FlowLayout());

        Vector<String> columns = new Vector<>();
        columns.add("ID");
        columns.add("Date");
        columns.add("Type");
        columns.add("Calories");

        Vector<Vector<String>> data = new Vector<>();
        Connection con = connection.connectDB();

        ResultSet resultSet = con.prepareStatement("SELECT * FROM meal_log WHERE name = '" + this.name + "'")
                                    .executeQuery();

        while (resultSet.next()) {
            Vector<String> row = new Vector<>();
            row.add(resultSet.getString("id"));
            row.add(resultSet.getString("date"));
            row.add(resultSet.getString("type"));
            row.add(resultSet.getDouble("calories") + " kcal");
            data.add(row);
        }


        JTable table = new JTable(data, columns);
        table.setDefaultEditor(Object.class, null);
        table.getColumnModel().getColumn(0).setMinWidth(0);
        panel.add(new JScrollPane(table));

        JButton addDietLogButton = new JButton("Add Diet Log");
        panel.add(addDietLogButton);
        addDietLogButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DisplayDietLogScreen();
            }
        });

        JButton viewNutrientsButton = new JButton("View Nutrients");
        panel.add(viewNutrientsButton);
        viewNutrientsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int row = table.getSelectedRow();
                if (row == -1) {
                    JOptionPane.showMessageDialog(null,
                            "Please select a diet log",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }
                long id = Long.parseLong(table.getValueAt(row, 0).toString());
                DisplayNutrientsScreen(id);
            }
        });

        JButton closeButton = new JButton("Close");
        panel.add(closeButton);
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                thisFrame.dispose();
                source.setVisible(true);
            }
        });

        panel.revalidate();
        panel.repaint();
    }

    private void DisplayNutrientsScreen(long id) {
        panel.removeAll();
        panel.setLayout(new BorderLayout());

        Vector<String> columns = new Vector<>();
        columns.add("Nutrient");
        columns.add("Amount");

        Vector<Vector<String>> data = new Vector<>();
        HashMap<String, Double> nutrients = new HashMap<>();
        Connection con;
        try {
            con = connection.connectDB();

            ResultSet resultSet = con.prepareStatement("SELECT * FROM meal_log WHERE id = " + id).executeQuery();
            resultSet.next();
            String type = resultSet.getString(3);
            String date = resultSet.getString(2);

            panel.add(new JLabel("Nutrient contents for " + type + " on " + date + "."), BorderLayout.NORTH);

            ResultSet mealNutrients = con.prepareStatement("SELECT * FROM meal_nutrient WHERE meal_content_id = " + id + " ORDER BY nutrient_name").executeQuery();
            while (mealNutrients.next()) {
                Vector<String> row = new Vector<>();
                row.add(mealNutrients.getString(2));
                row.add(String.valueOf(mealNutrients.getDouble(3)));
                data.add(row);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        JTable table = new JTable(data, columns);
        table.setDefaultEditor(Object.class, null);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JButton closeButton = new JButton("Close");
        panel.add(closeButton, BorderLayout.SOUTH);
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    viewMainForm();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        panel.revalidate();
        panel.repaint();
    }

    private void DisplayDietLogScreen() {
        HashMap<Integer, Double> addedFoods = new HashMap<>();
        panel.removeAll();
        panel.setLayout(new BorderLayout());

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new GridLayout(5, 2));

        JLabel dateLabel = new JLabel("Date (yyyy-MM-dd)");
        topPanel.add(dateLabel);
        JTextField dateField = new JTextField();
        topPanel.add(dateField);

        JLabel typeLabel = new JLabel("Type");
        topPanel.add(typeLabel);
        JComboBox<String> typeField = new JComboBox<>();
        typeField.addItem("Breakfast");
        typeField.addItem("Lunch");
        typeField.addItem("Dinner");
        typeField.addItem("Snack");
        topPanel.add(typeField);

        JLabel foodLabel = new JLabel("Food/Ingredient");
        topPanel.add(foodLabel);
        JComboBox<String> foodField = new JComboBox<>();
        try {
            Connection con = connection.connectDB();
            ResultSet resultSet = con.prepareStatement("SELECT * FROM food_name").executeQuery();
            while (resultSet.next()) {
                foodField.addItem(resultSet.getString("FoodDescription"));
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        topPanel.add(foodField);

        JLabel quantityLabel = new JLabel("Quantity");
        topPanel.add(quantityLabel);
        JTextField quantityField = new JTextField();
        topPanel.add(quantityField);

        topPanel.add(new JLabel());

        JButton addFoodButton = new JButton("Add Food");
        topPanel.add(addFoodButton);
        addFoodButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    if (!validateComboBox(foodField, "Please select a food") ||
                            !validateNumberField(quantityField, 0, "Please enter a quantity greater than 0"))
                        return;

                    Connection con = connection.connectDB();
                    ResultSet resultSet = con.prepareStatement("SELECT * FROM food_name WHERE FoodDescription = '" + foodField.getSelectedItem() + "' ORDER BY FoodDescription;").executeQuery();
                    resultSet.next();
                    int food_id = resultSet.getInt("FoodID");

                    addedFoods.put(food_id, Double.parseDouble(quantityField.getText()));

                    DefaultListModel<String> listModel = (DefaultListModel<String>) ((JList<String>) ((JScrollPane) panel.getComponent(1)).getViewport().getView()).getModel();
                    listModel.addElement(foodField.getSelectedItem() + " (" + quantityField.getText() + ")");

                    foodField.setSelectedIndex(0);
                    quantityField.setText("");
                } catch (Exception ex) {
                    System.out.println("Error: " + ex.getMessage());
                }
            }
        });


        DefaultListModel<String> listModel = new DefaultListModel<>();
        JList<String> list = new JList<>(listModel);
        list.setLayoutOrientation(JList.VERTICAL_WRAP);
        list.setVisibleRowCount(-1);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new GridLayout(1, 2));

        JButton saveButton = new JButton("Save");
        bottomPanel.add(saveButton);
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    if (!validateTextField(dateField, "Please enter a date") ||
                            !isDateValid(dateField.getText(), "Please enter a valid date in yyyy-MM-dd format.") ||
                            !validateComboBox(typeField, "Please select a type") ||
                            listModel.isEmpty()) {
                        return;
                    }


                    Connection con = connection.connectDB();

                    if (!typeField.getSelectedItem().toString().equals("Snack")) {
                        ResultSet resultSet = con.prepareStatement("SELECT * FROM meal_log WHERE name = '" + name +
                                "' AND date = '" + dateField.getText() + "' AND type = '" + typeField.getSelectedItem().toString() + "'")
                                .executeQuery();
                        if (resultSet.next()) {
                            JOptionPane.showMessageDialog(null,
                                    "You have already logged your " + typeField.getSelectedItem().toString().toLowerCase() + " for this day.",
                                    "Error",
                                    JOptionPane.ERROR_MESSAGE);
                            typeField.requestFocus();
                            return;
                        }
                    }

                    con.prepareStatement("INSERT INTO meal_log (name, date, type) VALUES ('" + name + "', '" + dateField.getText() + "', '" + typeField.getSelectedItem().toString() + "')").executeUpdate();
                    ResultSet resultSet = con.prepareStatement("SELECT * FROM meal_log WHERE name = '" + name + "' ORDER BY id DESC;").executeQuery();
                    resultSet.next();
                    int meal_id = resultSet.getInt("id");
                    double calories = 0;
                    HashMap<String, Double> nutrients = new HashMap<>();

                    for (int food_id : addedFoods.keySet()) {
                        ResultSet nutrientResult = con.prepareStatement("SELECT * FROM nutrientamount WHERE food_id = " + food_id).executeQuery();
                        while (nutrientResult.next()) {
                            ResultSet nutrientNameResult = con.prepareStatement("SELECT * FROM nutrient_name WHERE NutrientID = " + nutrientResult.getInt("nutrient_id")).executeQuery();
                            nutrientNameResult.next();
                            String nutrientName = nutrientNameResult.getString("NutrientName") + " (" + nutrientNameResult.getString("NutrientUnit") + ")";

                            if (nutrients.containsKey(nutrientName)) {
                                nutrients.put(nutrientName, nutrients.get(nutrientName) + nutrientResult.getDouble("NutrientValue") * addedFoods.get(food_id));
                            } else {
                                nutrients.put(nutrientName, nutrientResult.getDouble("NutrientValue") * addedFoods.get(food_id));
                            }

                            if (nutrientResult.getInt("nutrient_id") == 208) {
                                calories += nutrientResult.getDouble("NutrientValue") * addedFoods.get(food_id);
                            }
                        }
                    }

                    for (String nutrient : nutrients.keySet()) {
                        if (nutrients.get(nutrient) < 0.001)
                            continue;
                        con.prepareStatement("INSERT INTO meal_nutrient (nutrient_name, meal_content_id, total_amount) VALUES ('" + nutrient + "', " + meal_id + ", " + nutrients.get(nutrient) + ")").executeUpdate();
                    }

                    con.prepareStatement("UPDATE meal_log SET calories = " + calories + " WHERE id = " + meal_id).executeUpdate();

                    JOptionPane.showMessageDialog(null,
                            "Diet log saved",
                            "Success",
                            JOptionPane.INFORMATION_MESSAGE);

                    viewMainForm();
                } catch (Exception ex) {
                    System.out.println("Error: " + ex.getMessage());
                }

            }
        });

        JButton cancelButton = new JButton("Cancel");
        bottomPanel.add(cancelButton);
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    viewMainForm();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        panel.add(topPanel, BorderLayout.NORTH);
        panel.add(new JScrollPane(list));
        panel.add(bottomPanel, BorderLayout.SOUTH);

        panel.revalidate();
        panel.repaint();
    }

    private boolean validateComboBox(JComboBox<String> comboBox, String errorMessage) {
    	if (comboBox.getSelectedIndex() == -1) {
    		JOptionPane.showMessageDialog(null,
                    errorMessage,
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            comboBox.requestFocus();
    		return false;
    	}
    	return true;
    }

    private boolean validateNumberField(JTextField textField, double minimum, String errorMessage) {
    	if (textField.getText().equals("")) {
    		JOptionPane.showMessageDialog(null,
                    errorMessage,
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            textField.requestFocus();
    		return false;
    	}
    	if (Double.parseDouble(textField.getText()) <= minimum) {
    		JOptionPane.showMessageDialog(null,
                    errorMessage,
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            textField.requestFocus();
    		return false;
    	}
    	return true;
    }

    public boolean validateTextField(JTextField textField, String errorMessage) {
    	if (textField.getText().equals("")) {
    		JOptionPane.showMessageDialog(null,
                    errorMessage,
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            textField.requestFocus();
    		return false;
    	}
    	return true;
    }

    public boolean isDateValid(String date, String errorMessage) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        dateFormat.setLenient(false);
        try {
            dateFormat.parse(date);
            return true;
        } catch (ParseException | ClassCastException e) { 
            JOptionPane.showMessageDialog(null,
                    errorMessage,
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
}
