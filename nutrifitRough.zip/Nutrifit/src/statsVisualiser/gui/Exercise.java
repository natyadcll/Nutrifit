package statsVisualiser.gui;

import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.xdevapi.Statement;

import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.sql.*;
import java.awt.event.ActionEvent;

public class Exercise extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTable table_1;

	
	public Exercise(final String name, final String sex, final int height, final int weight, final String date,
			final String units) {
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 671, 521);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(201, 242, 254));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		table = new JTable();
		table.setBounds(328, 10, 0, 0);
		table.setColumnSelectionAllowed(true);
		table.setCellSelectionEnabled(true);
		contentPane.add(table);
		
		JButton newLog = new JButton("New Exercise Log");
		newLog.setBounds(480, 440, 167, 33);
		contentPane.add(newLog);
		newLog.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Excercise(name, sex, height, weight, date, units);
				dispose();
			}
		});
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 10, 637, 389);
		contentPane.add(scrollPane_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane_1.setViewportView(scrollPane);
		
		table_1 = new JTable();
		scrollPane.setViewportView(table_1);
		
		JButton display = new JButton("Display exercise logs");
		display.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
		        try {
		        	Connection con = null;
		        	con = connection.connectDB();
			        java.sql.Statement ps = con.createStatement();   
		        	String query = "SELECT * from exercise_log WHERE name = '" + name + "'";
		        	ResultSet rs = ps.executeQuery(query);
		        	ResultSetMetaData rsmd = rs.getMetaData();
		        	DefaultTableModel model = (DefaultTableModel) table_1.getModel();
		        	
		        	int cols = rsmd.getColumnCount();
		        	String[] colName = new String[cols];
		        	for (int i = 0; i <cols; i++) {
		        		colName[i]=rsmd.getColumnName(i+1);
		        	}
		        	model.setColumnIdentifiers(colName);
		        	String date, time, type, duration, inten, cals, name;
		        	while(rs.next()) {
		        		date = rs.getString(1);
		        		time = rs.getString(2);
		        		type = rs.getString(3);
		        		duration = rs.getString(4);
		        		inten = rs.getString(5);
		        		cals = rs.getString(6);
		        		name = rs.getString(7);
		        		String[] row = {date, time, type, duration, inten, cals, name};
		        		model.addRow(row);
		        	}
		        	ps.close();
		        	con.close();
		        }
		        catch(SQLException e1){
		        	e1.printStackTrace();
		        }

			}
		});
		
		JButton closeButton = new JButton("Close");
        contentPane.add(closeButton);
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	new Profile();
                dispose();
            }
        });
		
		display.setBounds(232, 410, 186, 33);
		contentPane.add(display);
	}
}
