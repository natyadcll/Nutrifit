package statsVisualiser.gui;

import java.awt.Component;
import java.awt.ComponentOrientation;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;
import java.text.DateFormat;
import java.text.ParseException;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel; 
import org.jfree.chart.JFreeChart; 
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset; 
import org.jfree.data.category.DefaultCategoryDataset; 
import org.jfree.ui.ApplicationFrame; 
import org.jfree.ui.RefineryUtilities; 
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import java.sql.*;  

public class visualization extends JFrame implements PropertyChangeListener{
    private static final String Invalid = null;
    Date stDate = null;
	Date enDate = null;
    
    
    public visualization() {
    	 setTitle("Nutrient Intake");
         setSize(1000, 1000);        
    	
         JPanel panel = new JPanel();

          
         JLabel StartLabel = new JLabel("Start Date :");
 		panel.add(StartLabel);
 		JFormattedTextField sDate = new JFormattedTextField("yyyy-mm-dd");
 		panel.add(sDate);
          
      
 		JLabel endLabel = new JLabel("End Date :");
 		panel.add(endLabel);
 		JFormattedTextField eDate = new JFormattedTextField("yyyy-mm-dd");
 		panel.add(eDate);
 		JButton enter = new JButton("check  date");
 		panel.add(enter);
          JButton nutrients = new JButton("visualise nutrients");
          nutrients.addActionListener(new ActionListener ()
          {
        	  public void actionPerformed(ActionEvent e)
        	  {
        		 nutri(stDate,enDate);
        	  }
          });
          enter.addActionListener(new ActionListener() {
         	 

			public void actionPerformed(ActionEvent e) {
         		String enteredsDate = sDate.getText();
         		String enteredeDate = eDate.getText();
              if (isValidDate(enteredsDate,enteredeDate)) {
            	  
            	  JOptionPane.showMessageDialog(null, 
         	                "valid Dates . You can visualize",
         	                "valid!!", 
         	                JOptionPane.INFORMATION_MESSAGE);
              } 
              else {
             	 JOptionPane.showMessageDialog(null, 
       	                "Invalid Dates . Try again",
       	                "Error!!", 
       	                JOptionPane.WARNING_MESSAGE);
              } 
              
         	 }

			private boolean isValidDate(String enteredsDate, String enteredeDate) {
				
				 DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
			        try {
			            stDate = dateFormat.parse(enteredsDate);
			        } catch (ParseException e) {
			            e.printStackTrace();
			        }
			        
			        try {
			            enDate = dateFormat.parse(enteredeDate);
			        } catch (ParseException e) {
			            e.printStackTrace();
			        }
			        if (enDate.after(stDate)) { return true; }
			        
			        return false;
					
			}
             
          });
         
          
         final JTextField t = new JTextField(5);
       
     	panel.add(nutrients);
     	
     	add(panel);
  	 	setVisible(true);	
    }

	@Override
	public void propertyChange(PropertyChangeEvent evt) {}
	
	      
	  
	
	private void nutri(Date stDate,Date enDate)
	{       

        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(stDate);

        while (!calendar.getTime().after(enDate)) {
            String dateStr = dateFormat.format(calendar.getTime());
            
            double value = 0;
    		Connection con1 = connection.connectDB();
    		try {

    			String sql = "SELECT NutrientValue FROM nutrient amount WHERE NutrientDateOfEntry=dateStr";
    			PreparedStatement ps = con1.prepareStatement(sql);
    			ps.setString(1, dateStr);
    			ResultSet resultSet = ps.executeQuery();
    			if (resultSet.next()) {
    				value = resultSet.getDouble("date");
    			}

    		} catch (SQLException e) {
    			e.printStackTrace();
    		}
    		
            
            
            
            
            
            
            
            dataset.addValue(value, "Value", dateStr);
            calendar.add(Calendar.DATE, 1);
        }

        JFreeChart barChart = ChartFactory.createBarChart(
                "Nutrients Intake", 
                "Date", 
                "Value", 
                dataset
        );

       
        displayChart(barChart);
    }

    public static void displayChart(JFreeChart chart) {
        JFrame frame = new JFrame("Nutrient intake Graph");
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new Dimension(800, 600));

        frame.getContentPane().add(chartPanel);
        frame.setVisible(true);
	   }
	   
	  
	   
		}
	


