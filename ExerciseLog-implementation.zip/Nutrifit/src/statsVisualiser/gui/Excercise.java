package statsVisualiser.gui;


import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.ComponentOrientation;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.DateFormat;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import java.sql.*;  



//As a user I want to be able to log my exercise in the application.
//I should be presented with a similar UI as the diet, where I can input the date and time of my exercise, 
//the type (walking, running, biking, swimming, and others), the duration 
//and the intensity (low, medium, high, very high). 
//The application will then calculate the calories burnt for every exercise 
//based on the duration, intensity, and BMR (as calculated by the profile data). 


public class Excercise extends JFrame implements PropertyChangeListener{
    private String date;
    private String time;
    private String type;
    private String intensity;
    private int durationMinutes;
    JFormattedTextField  textField = new JFormattedTextField(DateFormat.getDateInstance(DateFormat.SHORT));
    
    public Excercise() {

    	 setTitle("Exercise Log");
         setSize(1000, 1000);        
    	
         JPanel panel = new JPanel();
         String[] ExerciseType = {"Walk", "Run", "Cycling", "Elliptical", "Rower", "Stair Stepper", "HIIT", "Hiking", "Yoga", "Functional Strength Training", "Dance", "Cooldown", "Core Training", "Pilates", "Tai Chi", "Swimming", "Wheelchair", "Multisport", "Kickboxing" };
     	JComboBox<String> ExerciseList = new JComboBox<String>(ExerciseType);
     	ExerciseList.setSelectedIndex(ExerciseType.length-1);
     	ExerciseList.addActionListener(ExerciseList);
     	
     	ExerciseList.addActionListener(new ActionListener() {
  	        public void actionPerformed(ActionEvent e) {
  	            JComboBox<String> cb1 = (JComboBox<String>) e.getSource();
  	            String ExType = (String) cb1.getSelectedItem();
  	            setType(ExType);
  	        }
  	    });
     	
     	String[] intensity = {"Low", "Medium", "High", "Very High"};
     	JComboBox<String> intensityList = new JComboBox<String>(intensity);
     	intensityList.setSelectedIndex(intensity.length-1);
     	intensityList.addActionListener(intensityList);
     	
     	intensityList.addActionListener(new ActionListener() {
  	        public void actionPerformed(ActionEvent e) {
  	            JComboBox<String> cb2 = (JComboBox<String>) e.getSource();
  	            String intenLevel = (String) cb2.getSelectedItem();
  	            setInten(intenLevel);
  	        }
  	    });

     	JButton time = new JButton("save time");
     	 final JTextField timeField = new JTextField(5); // 5 columns wide
     	JLabel timeLabel = new JLabel("Time:");
     	timeLabel.setLabelFor(timeField);
         timeField.addKeyListener(new KeyListener() {
             @Override
             public void keyTyped(KeyEvent e) {
                 char c = e.getKeyChar();
                 if (!((c >= '0' && c <= '9') || c == ':' || c == KeyEvent.VK_BACK_SPACE || c == KeyEvent.VK_DELETE)) {
                     e.consume(); // Ignore the key event if it's not a valid input
                 }
             }
             @Override
             public void keyPressed(KeyEvent e) {
                 // Handle key pressed events if needed
             }

             @Override
             public void keyReleased(KeyEvent e) {
                 // Handle key released events if needed
             }
         });
         
         time.addActionListener(new ActionListener() {
        	 public void actionPerformed(ActionEvent e) {
        		String enteredTime = timeField.getText();
             if (isValidTime(enteredTime)) {
                 setTime(enteredTime);
             } 
             else {
            	 JOptionPane.showMessageDialog(null, 
      	                "Invalid Time Format. Try again",
      	                "Error", 
      	                JOptionPane.WARNING_MESSAGE);
             } 
        	 }
            
         });
          
         JButton b = new JButton("save duration");
          
         final JTextField t = new JTextField(5);
         JLabel durationLabel = new JLabel("Duration(minutes):");
      	durationLabel.setLabelFor(t);
         
         b.addActionListener(new ActionListener() {
             public void actionPerformed(ActionEvent e) {
  				durationMinutes(t);
             }
         });
     	panel.add(ExerciseList);
     	panel.add(intensityList);
     	panel.add(timeLabel);
        panel.add(timeField);
        panel.add(time);
        panel.add(durationLabel);
        panel.add(t);
        panel.add(b);

     	add(panel);
  	 	setVisible(true);
  	 	
  	 	Container cp = getContentPane();
		FlowLayout flowLayout = new FlowLayout();
		
		cp.setLayout(flowLayout);			
		 			
		 
		textField.setValue(new Date());
		textField.setPreferredSize(new Dimension(130, 30));
		    
		// display the window with the calendar
		final CalendarWindow calendarWindow = new CalendarWindow(); 
		    
		//wire a listener for the PropertyChange event of the calendar window
		calendarWindow.addPropertyChangeListener(this);
		
		
		JButton calendarButton = new JButton("Pick a Date");
				
		calendarButton.addActionListener(new ActionListener()
		{
		  public void actionPerformed(ActionEvent e)
		  {
			//render the calendar window below the text field
			calendarWindow.setLocation(textField.getLocationOnScreen().x, (textField.getLocationOnScreen().y + textField.getHeight()));
			//get the Date and assign it to the calendar
			Date d = (Date)textField.getValue();
			
			calendarWindow.resetSelection(d);				
			calendarWindow.setUndecorated(true);
		    calendarWindow.setVisible(true);
		  }
		});

		//add the UI controls to the ContentPane
		cp.add(textField);
		cp.add(calendarButton);
		cp.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
        
        

        JButton log = new JButton("Save workout");
		JButton results = new JButton("Results");
 		panel.add(log);
 		panel.add(results);
 		add(panel);
 	 	setVisible(true);
 	 	
 	 	
 	 	
 	 	results.addActionListener(new ActionListener() {
 	 		public void actionPerformed(ActionEvent e) {
 	 			System.out.println(getDate() +" "+
 	 			getTime()+" "+
 	 			getTypeExercise() +" "+
 	 			getDurationMinutes()+" "+
 	 			getInten());
 	 			
 	 		}
 	 	});
 	 	
 	 	log.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
				Log(e);
            }
        });
    }
    private boolean isValidTime(String input) {
    	if (input.matches("\\d{2}:\\d{2}")) {
            // Split the input into hours and minutes
            String[] parts = input.split(":");
            if (parts.length == 2) {
                try {
                    int hours = Integer.parseInt(parts[0]);
                    int minutes = Integer.parseInt(parts[1]);
                    // Validate hours and minutes
                    if (hours >= 0 && hours <= 23 && minutes >= 0 && minutes <= 59) {
                        return true;
                    }
                } catch (NumberFormatException e) {
                    // Parsing error, not valid
                }
            }
        }
        return false;
    }
    private void Log(ActionEvent e) {
    	//Save workout to database. If success show message
    	   Connection con = null;
           PreparedStatement ps = null;
    
           // Step 3: Establish the connection
           con = connection.connectDB();
    
           // Try block to check if exception/s occurs
           try {
        	    // Step 4: Create a statement
        	    String sql = "INSERT INTO exercise_log (`date`, `time`, `type_exercise`, `duration`, `intensity`) VALUES (?, ?, ?, ?, ?)";

        	    // Step 5: Execute the query
        	    ps = con.prepareStatement(sql);

        	    // Set the values for the placeholders (use the appropriate data types)
        	    ps.setString(1, this.date);
        	    ps.setString(2, this.time);
        	    ps.setString(3, this.type);
        	    ps.setInt(4, this.durationMinutes);
        	    ps.setString(5, this.intensity);

        	    // Execute the INSERT statement
        	    int rowsAffected = ps.executeUpdate();

        	    if (rowsAffected > 0) {
        	    	JOptionPane.showMessageDialog(null, 
        	                "Workout saved", 
        	                "Success", 
        	                JOptionPane.WARNING_MESSAGE);
        	    } else {
        	        //System.out.println("Data insertion failed.");
        	    	//If not able to save show message
        	    	JOptionPane.showMessageDialog(null, 
        	                "Unable to save Workout", 
        	                "Error", 
        	                JOptionPane.WARNING_MESSAGE);
        	    }
        	} catch (SQLException ex) {
        	    // Handle SQL exceptions here
        	    ex.printStackTrace();
        	} finally {
        	    // Close the connection and the statement
        	    try {
        	        if (con != null) {
        	            con.close();
        	        }
        	        if (ps != null) {
        	            ps.close();
        	        }
        	    } catch (SQLException ex) {
        	        ex.printStackTrace(); // Handle exceptions when closing resources
        	    }
        	}

	}

//    public double calculateCaloriesBurnt(UserProfile userProfile) {
//    	return 0.0;
//    }

    public void propertyChange(PropertyChangeEvent event) {
		
    	//get the selected date from the calendar control and set it to the text field
		if (event.getPropertyName().equals("selectedDate")) {
            
			java.util.Calendar cal = (java.util.Calendar)event.getNewValue();
			Date selDate =  cal.getTime();
			textField.setValue(selDate);
			setDate(selDate);
        }
		
	}
    
    
    public String getDate() {
    	return "Date: " + this.date;
    }
    public String getTime() {
    	return "Time: " + this.time.toString();
    }
    public String getTypeExercise() {
    	return "Type: "+this.type;
    }
    public String getDurationMinutes() {
    	return "Duration: "+ (this.durationMinutes);
    }
    public String getInten() {
    	return "Intensity: "+this.intensity;
    }
    
    public void setDate(Date date) {
    	String dateFormat = "yyyy-MM-dd"; 

        // Create a SimpleDateFormat object with the desired format
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);

        // Convert the Date to a String using the format
        String dateString = sdf.format(date);
    	this.date = dateString;
    }
    public void setTime(String time) {
    	this.time = time;
    }
    public void setType(String type) {
    	this.type = type;
    }
    public void setInten(String intensity) {
    	this.intensity = intensity;
    }
    public void durationMinutes(JTextField t) {
    	String text = t.getText();
    	int n = Integer.parseInt(text);
    	if(n<0) {
    		JOptionPane.showMessageDialog(null, 
                    "Duration not valid, please try again", 
                    "Error", 
                    JOptionPane.WARNING_MESSAGE);
    	}
    	else
    		this.durationMinutes = n;
    }
    
    public static void main(String[] args) {
		 new Excercise();
	}
    
}
