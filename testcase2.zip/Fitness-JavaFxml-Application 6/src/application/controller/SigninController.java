package application.controller;

import application.Start;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.io.IOException;

public class SigninController {
    public PasswordField passwordTextField;
    public TextField emailTextField;

    public void signupViewButton(ActionEvent actionEvent) throws IOException {
        FXMLLoader newLoader = new FXMLLoader(Start.class.getResource("view/SignupView.fxml"));
        Parent newRoot = newLoader.load();
        Scene newScene = new Scene(newRoot);
        Start.mainStage.setTitle("Register | Fitnyss Gym");
        Start.mainStage.setScene(newScene);
    }

    public void signinButton(ActionEvent actionEvent) throws IOException {
//        String password = passwordTextField.getText();
//        String email = emailTextField.getText();

        FXMLLoader newLoader = new FXMLLoader(Start.class.getResource("view/DashboardView.fxml"));
        Parent newRoot = newLoader.load();
        Scene newScene = new Scene(newRoot);
        Start.mainStage.setTitle("Register | Fitnyss Gym");
        Start.mainStage.setScene(newScene);

    }
}
