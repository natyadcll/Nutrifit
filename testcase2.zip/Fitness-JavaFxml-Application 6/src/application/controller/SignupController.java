package application.controller;

import application.Start;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.MenuButton;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class SignupController {
    public MenuButton genderMenu;
    public DatePicker dateOfBirthDatePicker;
    public PasswordField confirmPasswordTextField;
    public PasswordField passwordTextField;
    public TextField emailTextField;
    public TextField usernameTextField;
    public TextField fullNameTextField;

    public void loginViewButtonAction(ActionEvent actionEvent) throws IOException {
        FXMLLoader newLoader = new FXMLLoader(Start.class.getResource("view/LoginView.fxml"));
        Parent newRoot = newLoader.load();
        Scene newScene = new Scene(newRoot);
        Start.mainStage.setTitle("Login | Fitnyss Gym");
        Start.mainStage.setScene(newScene);
    }

    public void registerButtonAction(ActionEvent actionEvent) {

    }
}
