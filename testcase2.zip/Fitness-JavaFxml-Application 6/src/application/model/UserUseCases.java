package application.model;

import java.time.LocalDate;

public class UserUseCases {

    public static void main(String[] args) {
        // Example usage of the validation methods with random values
        LocalDate currentDate = LocalDate.now();
        LocalDate birthday = LocalDate.of(2000, 1, 1);

        System.out.println("Use Case 1:");
        System.out.println("1. User is Unique: " + isUserUnique(currentDate, birthday));
        System.out.println("2. Valid Username and Password: " + isValidUsernameAndPassword("username123", "password123"));
        System.out.println("3. Update Info Valid: " + isUpdateInfoValid("username123", "newUsername123"));
        System.out.println("4. Height and Weight Greater Than Zero: " + isPositiveNumber(160, 55));

        System.out.println("Use Case 2:");
        System.out.println("5. All Numbers Non-Negative: " + isNonNegativeNumber(42));
        System.out.println("6. Non-Negative Number (Not Allowed 0): " + isNonZeroValue(10));
        System.out.println("7. Contains Only Digits: " + containsOnlyDigits("12345"));

        System.out.println("Use Case 3:");
        System.out.println("8. Date Not Before Birthday: " + isDateValid(currentDate, birthday));

        System.out.println("Use Case 4:");
        System.out.println("9. Date Range Valid: " + isDateRangeValid("2023-01-01", "2022-01-01"));

        System.out.println("Use Case 6:");
        System.out.println("10. Date Not Before Birthday (Again): " + isDateValid(currentDate, birthday));
    }

    // Use Case 1: User should not be able to enter identical info as another user.
    public static boolean isUserUnique(LocalDate currentDate, LocalDate birthday) {
        // Simulate logic to check if the user is unique based on date comparison
        return !currentDate.isBefore(birthday);
    }

    // Use Case 1: Wrong username or password.
    public static boolean isValidUsernameAndPassword(String username, String password) {
        // Simulate logic to validate username and password
        return username.equals("username123") && password.equals("password123");
    }

    // Use Case 1: When updating, you cannot enter the exact info (info already exists).
    public static boolean isUpdateInfoValid(String currentInfo, String newInfo) {
        return !currentInfo.equals(newInfo);
    }

    // Use Case 1: Numbers greater than zero for height and weight, etc.
    public static boolean isPositiveNumber(double number1, double number2) {
        return number1 > 0 && number2 > 0;
    }

    // Use Case 2: All numbers must be non-negative.
    public static boolean isNonNegativeNumber(int number) {
        return number >= 0;
    }

    // Use Case 2: For some values, you cannot enter 0.
    public static boolean isNonZeroValue(int value) {
        return value != 0;
    }

    // Use Case 2: Non-numerical characters are not allowed.
    public static boolean containsOnlyDigits(String input) {
        return input.matches("\\d+");
    }

    // Use Case 3 & Use Case 6: Date cannot be before the birthday.
    public static boolean isDateValid(LocalDate date, LocalDate birthday) {
        return !date.isBefore(birthday);
    }

    // Use Case 4: End date cannot be before the start date and vice versa.
    public static boolean isDateRangeValid(String startDate, String endDate) {
        try {
            LocalDate start = LocalDate.parse(startDate);
            LocalDate end = LocalDate.parse(endDate);
            return !end.isBefore(start) && !start.isBefore(end);
        } catch (Exception e) {
            return false; // Invalid date format
        }
    }
}
