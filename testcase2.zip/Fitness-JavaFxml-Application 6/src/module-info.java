module Fitness.JavaFxml.Application {
    requires javafx.fxml;
    requires java.base;
    requires javafx.controls;
    requires javafx.graphics;

    opens application;
    opens application.view;
    opens application.controller;
}