package statsVisualiser.gui;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Profile extends JFrame {
	private Profile() {

        setTitle("Main Page");
        setSize(500, 500);
        
        JPanel panel = new JPanel();

        JButton login = new JButton("Login");
		panel.add(login);
        JButton signup = new JButton("Create Account");
		panel.add(signup);
		add(panel);
	 	setVisible(true);

		login.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
				Login();
            }
        });

        signup.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
				createAc();
            }
        });

	}
	private void createAc() {
		System.out.println("create");
		//sould give them option to edit profie

	}
	private void Login() {
		System.out.println("login");
		//once done, user can edit profile  or select account then sign in
	}
	

	public static void main(String[] args) {
		new Profile();
	}

}
