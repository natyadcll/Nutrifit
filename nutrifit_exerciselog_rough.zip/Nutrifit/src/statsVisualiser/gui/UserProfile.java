package statsVisualiser.gui;

public class UserProfile {
    private double bmr;

    public UserProfile(double bmr) {
        this.bmr = bmr;
    }

    public double getBMR() {
        return bmr;
    }
}
